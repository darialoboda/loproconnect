<template>
    <h1>{{ t('NotFound.title') }}</h1>
</template>
<script setup>
    import { t } from "@/i18n";
</script>